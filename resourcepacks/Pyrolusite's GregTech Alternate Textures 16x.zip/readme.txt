﻿/*------------*\
  DESCRIPTION 
\*------------*/

This resource pack is my take on GT 1.7 textures.

This resource pack is intended to be modular, which means you can add it to your resource pack list ingame - make sure it's placed above your main resource pack if you're using one modifying other textures of the mod - and it will run without any problems.

/*-----------*\
  LEGAL STUFF  
\*-----------*/

This Resource Pack is under a Creative Commons License - Attribution, Non Commercial, Share Alike 4.0 International - which means you can do whatever you want with it as long as you do not make money from it, credit me when using my work for whatever purpose and use the same license.
More info here : http://creativecommons.org/licenses/by-nc-sa/4.0/deed.en
