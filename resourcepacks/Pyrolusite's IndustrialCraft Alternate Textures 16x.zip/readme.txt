﻿/*------------*\
  DESCRIPTION 
\*------------*/

I made theses alternate textures a while ago, when Minecraft was at it's 1.2.5 version. I decided to pack them and update them with the lastest changes.

This resource pack is intended to be modulable, which means you can add it to your resource pack list ingame - make sure it's placed above your main resource pack if you're using one modifying other textures of the mod - and it will run without any problems.

For Minecraft versions prior to 1.7, you'll need to copy-paste the "assets" folder into your resource pack of choice. Yes, I grant you the permission to do so.

/*-----------*\
  LEGAL STUFF  
\*-----------*/

This Resource Pack is under a Creative Commons License - Attribution, Non Commercial, Share Alike 4.0 International - which means you can do whatever you want with it as long as it's not used for commercial purposes, and in case you make something public with it - ie modifying some parts and release it as your own alternative on MCF, Planet Minecraft or whatever - crediting my work and using the same license I used here.
More info here : http://creativecommons.org/licenses/by-nc-sa/4.0/deed.en

